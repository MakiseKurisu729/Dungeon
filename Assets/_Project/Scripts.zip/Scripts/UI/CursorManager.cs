using UnityEngine;

/// <summary>上下文光标 + 反引号清空选择。独立热点。</summary>
public class CursorManager : MonoBehaviour
{
    public static CursorManager instance;

    public Texture2D defaultCursor;
    public Texture2D selectCursor;
    public Texture2D attackCursor;
    public Texture2D interactCursor;
    public Texture2D grabCursor;

    public Vector2 defaultHotspot = new Vector2(4, 2);
    public Vector2 selectHotspot = new Vector2(56, 8);
    public Vector2 attackHotspot = new Vector2(56, 8);
    public Vector2 interactHotspot = new Vector2(32, 4);
    public Vector2 grabHotspot = new Vector2(32, 32);

    DebugCameraSwitcher _cam;
    SelectionManager _sel;

    void Awake()
    {
        instance = this;
        _cam = FindObjectOfType<DebugCameraSwitcher>();
        _sel = FindObjectOfType<SelectionManager>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.BackQuote) && _sel != null)
            _sel.ClearSelection();

        if (_cam != null && _cam.IsDragging) { Set(grabCursor, grabHotspot); return; }

        if (PauseManager.instance != null && PauseManager.instance.IsPaused) { Set(defaultCursor, defaultHotspot); return; }
        if (UIManager.instance != null && UIManager.instance.IsInventoryOpen) { Set(defaultCursor, defaultHotspot); return; }

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit[] hits = Physics.RaycastAll(ray, 300f);
        System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));

        foreach (var h in hits)
        {
            if (h.collider.GetComponentInParent<Selectable>() != null) { Set(selectCursor, selectHotspot); return; }
            var uh = h.collider.GetComponentInParent<UnitHealth>();
            if (uh != null && uh.team == Team.Monster && !uh.dead) { Set(attackCursor, attackHotspot); return; }
            if (h.collider.GetComponentInParent<Interactable>() != null) { Set(interactCursor, interactHotspot); return; }
        }
        Set(defaultCursor, defaultHotspot);
    }

    Texture2D _current;
    Vector2 _currentHotspot;
    void Set(Texture2D tex, Vector2 hotspot)
    {
        if (tex == _current && hotspot == _currentHotspot) return;
        _current = tex;
        _currentHotspot = hotspot;
        Cursor.SetCursor(tex, hotspot, CursorMode.ForceSoftware);
    }
}
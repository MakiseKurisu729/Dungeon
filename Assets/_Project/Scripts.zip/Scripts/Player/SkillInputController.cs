using UnityEngine;

/// <summary>
/// 技能输入：QWER → 需目标的技能进入瞄准模式（范围圈+指向线）；
/// 左键选定释放 / 右键·Esc 取消；quickCast 快捷施法（后续接设置界面）。
/// </summary>
public class SkillInputController : MonoBehaviour
{
    public static SkillInputController instance;
    public static bool IsTargeting { get; private set; }

    [Tooltip("快捷施法：跳过目标指示，直接对最近敌人释放")]
    public bool quickCast = false;

    public SkillIndicator indicator;
    public KeyCode[] skillKeys = { KeyCode.Q, KeyCode.W, KeyCode.E, KeyCode.R };

    int _pendingIndex = -1;

    void Awake() { instance = this; }

    void Update()
    {
        if (PauseManager.instance != null && PauseManager.instance.IsPaused) return;
        if (UIManager.instance != null && UIManager.instance.IsInventoryOpen) return;

        var ss = PrimarySkillSystem();

        if (IsTargeting)
        {
            if (ss == null || ss.GetSkill(_pendingIndex) == null) { Cancel(); return; }

            float range = GetSkillRange(ss.GetSkill(_pendingIndex));
            indicator.UpdateVisual(ss.transform.position, range);

            if (Input.GetMouseButtonDown(1) || Input.GetKeyDown(KeyCode.Escape))
            {
                Cancel();
            }
            else if (Input.GetMouseButtonDown(0))
            {
                ss.Cast(_pendingIndex, PickEnemy());
                Cancel();
            }
            return;
        }

        if (ss == null) return;

        for (int i = 0; i < skillKeys.Length && i < 4; i++)
        {
            if (!Input.GetKeyDown(skillKeys[i])) continue;
            var s = ss.GetSkill(i);
            if (s == null || s.effects == null || s.effects.Length == 0) continue;

            if (quickCast)
                ss.Cast(i, NearestEnemy(ss.transform, GetSkillRange(s)));
            else
            {
                _pendingIndex = i;
                IsTargeting = true;
                indicator.Show();
            }
        }
    }

    // ★ 范围取第一个效果的 range（效果资产上）
    static float GetSkillRange(SkillData s)
    {
        if (s.effects != null && s.effects.Length > 0 && s.effects[0] != null)
            return s.effects[0].range;
        return 3f;
    }

    void Cancel()
    {
        IsTargeting = false;
        _pendingIndex = -1;
        if (indicator != null) indicator.Hide();
    }

    SkillSystem PrimarySkillSystem()
    {
        if (SelectionManager.instance == null || SelectionManager.instance.Primary == null) return null;
        return SelectionManager.instance.Primary.GetComponentInParent<SkillSystem>();
    }

    Transform PickEnemy()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit[] hits = Physics.RaycastAll(ray, 300f);
        System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));
        foreach (var h in hits)
        {
            var uh = h.collider.GetComponentInParent<UnitHealth>();
            if (uh != null && uh.team == Team.Monster && !uh.dead)
                return uh.transform;
        }
        return null;
    }

    static Transform NearestEnemy(Transform from, float range)
    {
        UnitHealth best = null;
        float bd = range;
        foreach (var h in FindObjectsByType<UnitHealth>(FindObjectsSortMode.None))
        {
            if (h.dead || h.team != Team.Monster) continue;
            float d = Vector3.Distance(from.position, h.transform.position);
            if (d < bd) { bd = d; best = h; }
        }
        return best != null ? best.transform : null;
    }
}
using UnityEngine;

/// <summary>可选中单位：注册选择系统，管理选中圈；hotkeyIndex=1~4 数字键选人。</summary>
public class Selectable : MonoBehaviour
{
    public GameObject selectionRing;
    [Tooltip("1~4 数字键快速选中（0=不参与）")]
    public int hotkeyIndex = 0;

    void OnEnable()
    {
        if (SelectionManager.instance != null)
            SelectionManager.instance.Register(this);
    }

    public void SetSelected(bool on)
    {
        if (selectionRing != null) selectionRing.SetActive(on);
    }
}
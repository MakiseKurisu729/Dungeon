using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 选择系统：左键=选角色/点敌集火/点交互物下达交互指令/点空地取消；
/// Ctrl+左键加选；Ctrl+A 全选；1~4 按热键选人；反引号清空；瞄准技能时左键让给施法。
/// </summary>
public class SelectionManager : MonoBehaviour
{
    public static SelectionManager instance;

    public LayerMask clickableLayers = ~0;

    readonly List<Selectable> _all = new List<Selectable>();
    readonly List<Selectable> _selected = new List<Selectable>();
    DebugCameraSwitcher _cam;

    public Selectable Primary
    {
        get { return _selected.Count > 0 ? _selected[_selected.Count - 1] : null; }
    }

    public bool MultiSelected { get { return _selected.Count > 1; } }

    void Awake()
    {
        instance = this;
        _cam = FindObjectOfType<DebugCameraSwitcher>();
    }

    public void Register(Selectable s)
    {
        if (!_all.Contains(s)) _all.Add(s);
    }

    public void ClearSelection()
    {
        _selected.Clear();
        RefreshRings();
    }

    public void ForEachSelectedBrain(System.Action<CharacterBrain> action)
    {
        foreach (var s in _selected)
        {
            var b = s.GetComponentInParent<CharacterBrain>();
            if (b != null) action(b);
        }
    }

    Vector2 _downPos;
    bool _moved;

    void Update()
    {
        if (PauseManager.instance != null && PauseManager.instance.IsPaused) return;

        // 1~4 快速选人
        for (int i = 0; i < 4; i++)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
            {
                var target = _all.Find(s => s != null && s.hotkeyIndex == i + 1);
                if (target != null) SingleSelect(target);
            }
        }
        if (Input.GetKeyDown(KeyCode.A) && (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl)))
        {
            _selected.Clear();
            foreach (var s in _all)
                if (s != null && s.GetComponentInParent<UnitHealth>() != null
                    && s.GetComponentInParent<UnitHealth>().team == Team.Player)
                    _selected.Add(s);
            RefreshRings();
        }

        if (Input.GetMouseButtonDown(0)) { _downPos = Input.mousePosition; _moved = false; }
        if (Input.GetMouseButton(0) && ((Vector2)Input.mousePosition - _downPos).magnitude > 8f)
            _moved = true;
        // 技能瞄准中：左键归施法系统
        if (Input.GetMouseButtonUp(0) && !_moved && !(SkillInputController.instance != null && SkillInputController.IsTargeting))
            HandleClick();

        if (_cam != null)
        {
            _cam.allowPan = _selected.Count == 0;
            if (Primary != null) _cam.SetFocus(Primary.transform);
        }
    }

    void HandleClick()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit[] hits = Physics.RaycastAll(ray, 300f, clickableLayers);
        System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));

        Selectable sel = null;
        UnitHealth enemy = null;
        Interactable inter = null;
        foreach (var h in hits)
        {
            if (sel == null)
            {
                var s = h.collider.GetComponentInParent<Selectable>();
                if (s != null) sel = s;
            }
            if (enemy == null)
            {
                var uh = h.collider.GetComponentInParent<UnitHealth>();
                if (uh != null && uh.team == Team.Monster && !uh.dead) enemy = uh;
            }
            if (inter == null && h.collider.GetComponentInParent<Interactable>() != null)
                inter = h.collider.GetComponentInParent<Interactable>();
        }

        bool ctrl = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);

        if (sel != null)
        {
            if (ctrl) ToggleSelect(sel);
            else SingleSelect(sel);
        }
        else if (enemy != null)
        {
            foreach (var s in _selected)
            {
                var brain = s.GetComponent<CharacterBrain>();
                if (brain != null) brain.CommandAttack(enemy.transform);
            }
        }
        else if (inter != null)
        {
            foreach (var s in _selected)
            {
                var brain = s.GetComponent<CharacterBrain>();
                if (brain != null) brain.CommandInteract(inter);
            }
        }
        else SingleSelect(null);
    }

    void SingleSelect(Selectable s)
    {
        _selected.Clear();
        if (s != null) _selected.Add(s);
        RefreshRings();
    }

    void ToggleSelect(Selectable s)
    {
        if (_selected.Contains(s)) _selected.Remove(s);
        else _selected.Add(s);
        RefreshRings();
    }

    void RefreshRings()
    {
        foreach (var s in _all) if (s != null) s.SetSelected(_selected.Contains(s));
    }
}
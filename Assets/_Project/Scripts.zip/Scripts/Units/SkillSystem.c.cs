using UnityEngine;

/// <summary>
/// 技能系统：QWER 四槽（数据驱动）；验蓝+验冷却（Cooldown 结构）；
/// 效果链执行（策略模式，新增效果不改本类）。
/// </summary>
public class SkillSystem : MonoBehaviour
{
    public UnitMana mana;
    public SwordSwing sword;

    [Tooltip("Q/W/E/R，空槽留空")]
    public SkillData[] skills = new SkillData[4];

    [Header("盾击节奏")]
    public float bashTotalTime = 0.6f;
    public float bashHitTime = 0.3f;

    readonly Cooldown[] _cds = new Cooldown[4];
    Animator _animator;
    float _bashTimer = -1f;
    bool _bashDidHit;
    Transform _bashTarget;
    BashEffect _bashEffect;

    void Awake()
    {
        _animator = GetComponentInChildren<Animator>();
        for (int i = 0; i < _cds.Length; i++) _cds[i] = new Cooldown();
    }

    public SkillData GetSkill(int i) { return i >= 0 && i < skills.Length ? skills[i] : null; }
    public float CdRemaining(int i) { return i < _cds.Length ? _cds[i].Remaining : 0f; }
    public float CdTotal(int i) { var s = GetSkill(i); return s != null ? s.cooldown.duration : 1f; }

    /// <summary>施放：验蓝验冷却 → 效果链。target 仅需要目标的技能用。</summary>
    public bool Cast(int index, Transform target)
    {
        var s = GetSkill(index);
        if (s == null || s.effects == null || s.effects.Length == 0) return false;
        if (!_cds[index].Ready) { GameData.SetMessage($"{s.skillName} 冷却中"); return false; }
        if (mana == null || !mana.Consume(s.manaCost)) { GameData.SetMessage("蓝量不足"); return false; }

        foreach (var eff in s.effects)
        {
            if (!eff.CanCast(this, target)) return false;
        }
        foreach (var eff in s.effects)
        {
            eff.Execute(this, target);
        }

        _cds[index] = s.cooldown;
        _cds[index].Trigger();
        return true;
    }

    /// <summary>由 BashEffect 调用：开始盾击协同时序。</summary>
    public void StartBash(BashEffect eff, Transform target)
    {
        _bashEffect = eff;
        _bashTarget = target;
        _bashTimer = 0f;
        _bashDidHit = false;
        Vector3 d = target.position - transform.position; d.y = 0f;
        transform.rotation = Quaternion.LookRotation(d);
        if (_animator != null) _animator.SetTrigger("Bash");
    }

    void Update()
    {
        if (_bashTimer < 0f) return;
        _bashTimer += Time.deltaTime;
        float t01 = _bashTimer / bashTotalTime;

        if (!_bashDidHit && t01 >= bashHitTime / bashTotalTime)
        {
            _bashDidHit = true;
            var uh = _bashTarget != null ? _bashTarget.GetComponent<UnitHealth>() : null;
            if (uh != null && !uh.dead && _bashEffect != null)
            {
                float dmg = sword != null ? sword.GetRawDamage() : 10f;
                uh.TakeHit(dmg, 999f, DamageType.Blunt, uh.transform.position + Vector3.up * 0.6f,
                           GetComponent<UnitHealth>());
                var brain = uh.GetComponent<MonsterBrain>();
                if (brain != null)
                {
                    Vector3 dir = uh.transform.position - transform.position; dir.y = 0f;
                    brain.ForceHit(dir, _bashEffect.stagger, _bashEffect.knockDist, _bashEffect.knockDuration);
                }
            }
        }
        if (t01 >= 1f) _bashTimer = -1f;
    }
}
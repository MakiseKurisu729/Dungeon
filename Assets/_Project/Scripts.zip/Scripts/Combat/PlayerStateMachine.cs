using System;
using UnityEngine;

public enum PlayerState
{
    Sheathed,   // 未拔剑（探索）
    Combat,     // 拔剑（战斗）
    Charging,   // 蓄力
    Attacking   // 攻击中
}

public class PlayerStateMachine : MonoBehaviour
{
    public PlayerState Current { get; private set; } = PlayerState.Sheathed;

    /// <summary>参数：新状态, 旧状态</summary>
    public event Action<PlayerState, PlayerState> OnStateChanged;

    public void ChangeState(PlayerState next)
    {
        if (next == Current) return;
        var prev = Current;
        Current = next;
        OnStateChanged?.Invoke(next, prev);
    }
}
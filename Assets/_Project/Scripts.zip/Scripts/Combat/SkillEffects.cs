using UnityEngine;

/// <summary>盾击：指定敌人，命中触发受击打断 + 线性击退 + 普攻伤害。</summary>
[CreateAssetMenu(menuName = "Dungeon/Skill Effects/Bash")]
public class BashEffect : SkillEffectBase
{
    public float stagger = 0.5f;
    public float knockDist = 2f;
    public float knockDuration = 0.3f;
    public float bashLen = 0.6f;

    public override bool CanCast(SkillSystem caster, Transform target)
    {
        if (target == null) { GameData.SetMessage("盾击需要选择一个敌人目标"); return false; }
        var uh = target.GetComponent<UnitHealth>();
        if (uh == null || uh.dead) { GameData.SetMessage("盾击需要选择一个敌人目标"); return false; }
        Vector3 d = uh.transform.position - caster.transform.position; d.y = 0f;
        if (d.magnitude > range) { GameData.SetMessage("目标超出技能范围"); return false; }
        return true;
    }

    public override void Execute(SkillSystem caster, Transform target)
    {
        caster.StartBash(this, target);
    }
}

/// <summary>强化斩：立即释放一次大威力近战攻击。</summary>
[CreateAssetMenu(menuName = "Dungeon/Skill Effects/Heavy Slash")]
public class HeavySlashEffect : SkillEffectBase
{
    public HeavySlashEffect() { needTarget = false; }

    public override bool CanCast(SkillSystem caster, Transform target) { return caster.sword != null; }

    public override void Execute(SkillSystem caster, Transform target)
    {
        caster.sword.DoSkillAttack();
    }
}
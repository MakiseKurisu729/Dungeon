using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 近战执行器：命中窗口读【动画时钟】（UpperBody 层 normalizedTime 轮询），
/// 与攻速/过渡天然同步；失败回退代码时钟。
/// </summary>
public class SwordSwing : MonoBehaviour, ICharacterCombat
{
    [Header("引用")]
    public Transform sword;
    public Transform shield;
    public WeaponData weapon;
    public Material ringMaterial;
    public Material trailMaterial;
    public UnitStats stats;
    public UnitHealth health;

    [Header("攻击动画")]
    public float attackLen = 0.8f;
    [Range(0f, 1f)] public float activeStart = 0.35f;
    [Range(0f, 1f)] public float activeEnd = 0.55f;

    [Header("动画状态名（UpperBody 层）")]
    public string attackStateName = "Attack";
    public string skillStateName = "Skill";
    public int attackLayer = 1;

    [Header("命中")]
    public float bladeLength = 1.05f;
    public float hitRadius = 0.28f;

    [Header("强化斩（技能用）")]
    public float skillLen = 1.3f;
    [Range(0f, 1F)] public float skillActiveStart = 0.5f;
    [Range(0f, 1f)] public float skillActiveEnd = 0.7f;

    [Header("伤害")]
    public float strengthBase = 1f;
    public float strengthDamageFactor = 0.5f;
    public float dmgMult = 1f;

    [Header("调试可视化")]
    public bool showDebug = true;
    public float trailPersistTime = 0.25f;

    Animator _animator;
    float _timer = -1f;
    float _curLen;
    bool _isSkill;
    float _sharpness, _radiusMult = 1f;

    Vector3 _prevHilt, _prevTip;
    readonly HashSet<int> _hitIds = new HashSet<int>();
    LineRenderer _tipTrail, _hiltTrail;
    readonly LineRenderer[] _sphere = new LineRenderer[3];
    readonly List<Vector3> _tipPts = new List<Vector3>();
    readonly List<Vector3> _hiltPts = new List<Vector3>();
    float _trailLife;

    float SpeedMult { get { return stats != null && stats.attackSpeed > 0f ? stats.attackSpeed : 1f; } }

    void Awake()
    {
        _animator = GetComponentInChildren<Animator>();
        _tipTrail = MakeLine(0.05f, false);
        _hiltTrail = MakeLine(0.025f, false);
        for (int i = 0; i < 3; i++) _sphere[i] = MakeLine(0.008f, true);
    }

    LineRenderer MakeLine(float width, bool loop)
    {
        var lr = new GameObject("dbg_line").AddComponent<LineRenderer>();
        lr.material = trailMaterial != null ? trailMaterial : ringMaterial;
        lr.useWorldSpace = true;
        lr.loop = loop;
        lr.positionCount = 33;
        lr.startWidth = width;
        lr.endWidth = width;
        lr.enabled = false;
        return lr;
    }

    void Start()
    {
        dmgMult += (GameData.level - 1) * 0.25f;
        if (sword != null) sword.gameObject.SetActive(true);
        if (shield != null) shield.gameObject.SetActive(true);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F1))
        {
            showDebug = !showDebug;
            if (!showDebug) _trailLife = 0f;
        }

        if (_timer < 0f) return;
        _timer += Time.deltaTime;

        // ★ 动画时钟优先：读 UpperBody 层攻击状态进度
        float t01 = ReadAnimProgress();
        if (t01 < 0f) t01 = _timer / _curLen;      // 回退代码时钟

        float wS = _isSkill ? skillActiveStart : activeStart;
        float wE = _isSkill ? skillActiveEnd : activeEnd;

        if (t01 >= wS && t01 <= wE)
        {
            DetectHit();
            _tipPts.Add(sword.position + sword.up * bladeLength);
            _hiltPts.Add(sword.position);
        }

        if (_timer >= _curLen) _timer = -1f;
        UpdateDebug();
    }

    float ReadAnimProgress()
    {
        if (_animator == null || attackLayer >= _animator.layerCount) return -1f;
        var st = _animator.GetCurrentAnimatorStateInfo(attackLayer);
        if (st.IsName(attackStateName) || st.IsName(skillStateName))
            return st.normalizedTime % 1f;
        return -1f;
    }

    public void AutoAttack(Transform target) { DoAttack(false); }

    public void CancelAttack()
    {
        if (_timer < 0f) return;
        _timer = -1f;
        if (_animator != null)
        {
            _animator.ResetTrigger("Attack");
            _animator.ResetTrigger("Skill");
            _animator.SetTrigger("Interrupt");
        }
    }

    public void DoSkillAttack() { DoAttack(true); }

    public float GetRawDamage()
    {
        float baseDamage = weapon != null ? weapon.baseDamage : 10f;
        return baseDamage * (1f + strengthBase * strengthDamageFactor) * dmgMult;
    }

    void DoAttack(bool skill)
    {
        if (_timer >= 0f) return;
        _isSkill = skill;
        _sharpness = (weapon != null ? weapon.sharpness : 8f) + (skill ? 5f : 0f);
        _radiusMult = skill ? 1.6f : 1f;
        _curLen = (skill ? skillLen : attackLen) / SpeedMult;

        if (_animator != null)
        {
            _animator.ResetTrigger("Interrupt");
            _animator.SetTrigger(skill ? "Skill" : "Attack");
        }

        _prevHilt = sword.position;
        _prevTip = sword.position + sword.up * bladeLength;
        _hitIds.Clear();
        _tipPts.Clear();
        _hiltPts.Clear();
        _trailLife = trailPersistTime + _curLen;
        _timer = 0f;
    }

    void DetectHit()
    {
        Vector3 hilt = sword.position;
        Vector3 tip = sword.position + sword.up * bladeLength;
        CheckSegment(_prevHilt, hilt);
        CheckSegment(_prevTip, tip);
        _prevHilt = hilt;
        _prevTip = tip;
    }

    void CheckSegment(Vector3 from, Vector3 to)
    {
        Vector3 d = to - from;
        if (d.sqrMagnitude < 0.0001f) return;
        if (d.magnitude > 1.5f) return;

        float raw = GetRawDamage() * (_isSkill ? 2f : 1f);

        RaycastHit[] hits = Physics.SphereCastAll(from, hitRadius * _radiusMult, d.normalized, d.magnitude);
        foreach (var h in hits)
        {
            var uh = h.collider.GetComponentInParent<UnitHealth>();
            if (uh == null || uh.team != Team.Monster || !_hitIds.Add(uh.GetInstanceID())) continue;
            uh.TakeHit(raw, _sharpness, DamageType.Slash, h.point, health);
        }
    }

    void UpdateDebug()
    {
        bool showSphere = showDebug && sword != null;
        for (int i = 0; i < 3; i++) _sphere[i].enabled = showSphere;
        if (showSphere)
        {
            Vector3 center = sword.position + sword.up * bladeLength;
            float r = hitRadius * _radiusMult;
            for (int axis = 0; axis < 3; axis++)
                for (int i = 0; i <= 32; i++)
                {
                    float a = i / 32f * Mathf.PI * 2f;
                    Vector3 off = axis == 0 ? new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0f)
                                : axis == 1 ? new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a))
                                : new Vector3(0f, Mathf.Cos(a), Mathf.Sin(a));
                    _sphere[axis].SetPosition(i, center + off * r);
                }
        }

        _trailLife -= Time.deltaTime;
        bool showTrail = _trailLife > 0f && _tipPts.Count > 1;
        _tipTrail.enabled = showTrail;
        _hiltTrail.enabled = showTrail;
        if (showTrail)
        {
            _tipTrail.positionCount = _tipPts.Count;
            _tipTrail.SetPositions(_tipPts.ToArray());
            _hiltTrail.positionCount = _hiltPts.Count;
            _hiltTrail.SetPositions(_hiltPts.ToArray());
        }
    }
}